const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

// Initialize the app
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// PostgreSQL connection setup
const pool = new Pool({
    user: 'postgres',
    host: 'postgres',
    //database: 'your_db_name',
    password: 'postgres',
    port: 5432, // Default PostgreSQL port
});

// Ensure the `users` table exists
const createUsersTable = async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(100) NOT NULL
            )
        `);
        console.log('Users table ensured.');
    } catch (err) {
        console.error('Error creating users table:', err);
    }
};

createUsersTable();
pool.database = 'users';
// Routes
// Root GET route
app.get('/', (req, res) => {
    res.send('Welcome to the API!');
});

// Register POST route
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await pool.query(
            'INSERT INTO users (username, password) VALUES ($1, $2) RETURNING *',
            [username, password]
        );
        res.status(201).json({ message: 'User registered successfully', user: result.rows[0] });
    } catch (err) {
        console.error('Error registering user:', err);
        res.status(500).json({ error: 'User registration failed. Username may already exist.' });
    }
});

// Login POST route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await pool.query(
            'SELECT * FROM users WHERE username = $1 AND password = $2',
            [username, password]
        );

        if (result.rows.length > 0) {
            res.json({ message: 'Login successful', user: result.rows[0] });
        } else {
            res.status(401).json({ error: 'Invalid username or password' });
        }
    } catch (err) {
        console.error('Error logging in user:', err);
        res.status(500).json({ error: 'Login failed' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
